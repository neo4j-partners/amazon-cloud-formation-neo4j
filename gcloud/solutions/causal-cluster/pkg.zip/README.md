# Deployment Manager Templates

This directory contains jinja deployment manager templates that are used to define how the cluster gets deployed in google.

The original template was auto-generated from the partner portal.  For neo4j, we have a GCP project called launcher-public which is where public facing artifacts reside.  If you go to the google cloud console, choose Cloud Launcher -> Partner Portal, there you can adjust settings related to the "Solution" we have posted.

A zip of this directory can also be uploaded there to change deployment configuration for the solution.


