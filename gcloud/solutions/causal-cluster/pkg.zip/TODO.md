- Hardwire image URL -- it must change with every deploy.  Also c2d file.
- Move image from dev project to public project following https://cloud.google.com/launcher/docs/partners/technical-components#create_the_base_solution_vm

- Change URL to point to dev https://console.cloud.google.com/launcher/config/neo4j-public/neo4j-enterprise-causal-cluster?src=console&project=launcher-public&preview=neo4j-public%2Fneo4j-enterprise-causal-cluster


